import { faPlay } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { useNavigate } from "react-router-dom";


      // Data for the Videos

const videos = [
  {
    id: 1,
    src: "./video1.mp4",
  },
  {
    id: 2,
    src: "./video2.mp4",
  },
  {
    id: 3,
    src: "./video3.mp4",
  },
  {
    id: 1,
    src: "./video1.mp4",
  },
  {
    id: 2,
    src: "./video2.mp4",
  },
  {
    id: 3,
    src: "./video3.mp4",
  },
  {
    id: 1,
    src: "./video1.mp4",
  },
  {
    id: 2,
    src: "./video2.mp4",
  },
  {
    id: 3,
    src: "./video3.mp4",
  }
  
  
];



      // Main Video Section for All Videos

const AllVideos = () => {
  const navigate = useNavigate()
  return (
    <React.Fragment>
      <h1 className="pt-2 font-semibold mt-1 ps-[100px] bg-white">Enterpreneur & Invester Videos</h1>
      <div className="bg-white px-2">
      <div className="flex flex-wrap justify-between bg-white w-[80%] mx-auto">
        {videos.map((video,ind) => (
          <div key={ind} className="w-[33%] mt-3  grid place-items-center  relative  h-[40vh]" onClick={()=>navigate(`/video/${video.src}`)}>
            <video
              src={video.src}
              className=" w-[100%] h-[100%] overflow-y-hidden object-cover"
            ></video>
            <FontAwesomeIcon icon={faPlay} className="absolute text-2xl text-white" />
          </div>
        ))}
      </div>
      </div>
    </React.Fragment>
  );
};

export default AllVideos;
